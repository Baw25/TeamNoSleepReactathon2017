'use-strict';
var fs = require('fs');
var axios = require('axios');
var token;
try {
  token = JSON.parse(fs.readFileSync('./accessToken.json'));
  axios.defaults.headers.authorization = "Bearer " + token.access_token;
} catch (e) {
  axios.defaults.headers.authorization = "Bearer " + "27037c67-f394-4cfd-ab51-069ac71132fb";
  console.log('Configure accessToken.json in service folder');
}


module.exports.listings = (event, context, callback) => {
  axios.get('https://platform.otqa.com/sync/listings')
  .then(response => {
    var customResponse =  {
      status: response.status,
      data: response.data
    };
    callback(null, customResponse);
  })
  .catch(error => {
    callback(error);
  });
};

module.exports.reserve = (event, context, callback) => {
  axios.post("https://platform.opentable.com/booking/reservations")
  .then(response => {
    var customResponse = {
      status: response.status,
      data: response.data
    }
    callback(null, customResponse);
  })
  .catch(error => {
    callback(error);
  });
}